<?php

use ChurchCRM\dto\SystemURLs;
use ChurchCRM\dto\SystemConfig;
use ChurchCRM\Utils\CurrencyFormatter;
use ChurchCRM\Utils\InputUtils;

require SystemURLs::getDocumentRoot() . '/Include/Header.php';

?>

<div class="container-fluid">
    <!-- Page Title -->
    <div class="row mb-4">
        <div class="col-12">
            <h2><?= gettext('Pledge Dashboard') ?></h2>
            <p class="text-body-secondary small">
                <?= gettext('Track and manage pledge commitments by family and fund') ?>
            </p>
        </div>
    </div>

    <!-- Fiscal Year Selector -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="GET" class="form-inline">
                        <label for="fyid" class="me-2"><?= gettext('Select Fiscal Year') ?>:</label>
                        <select name="fyid" id="fyid" class="form-select me-3" onchange="this.form.submit();">
                            <option value="">-- <?= gettext('select an option') ?> --</option>
                            <?php foreach ($availableYears as $year): ?>
                                <option value="<?= $year['id'] ?>" <?= $year['id'] == $selectedFyid ? 'selected' : '' ?>>
                                    <?= InputUtils::escapeHTML($year['label']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Results Table -->
    <div class="row">
        <div class="col-12">
            <?php if (empty($familyPledges)): ?>
                <div class="alert alert-info">
                    <i class="fa-solid fa-circle-info"></i>
                    <?= gettext('No pledges found for the selected fiscal year') ?>
                </div>
            <?php else: ?>
                <div class="card">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <?= gettext('Family Pledges') ?> 
                            <span class="badge bg-primary ms-2"><?= count($familyPledges) ?> <?= gettext('Families') ?></span>
                        </h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="bg-light">
                                    <tr>
                                        <th><?= gettext('Family Name') ?></th>
                                        <th><?= gettext('Pledged By') ?></th>
                                        <?php if (SystemConfig::getBooleanValue('bUseDonationEnvelopes')): ?>
                                        <th><?= gettext('Envelope') ?></th>
                                        <?php endif; ?>
                                        <th><?= gettext('Fund Name') ?></th>
                                        <th class="text-end"><?= gettext('Pledge Amount') ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($familyPledges as $family): ?>
                                        <?php foreach ($family['pledges'] as $pledge): ?>
                                            <tr>
                                                <td class="align-middle fw-bold">
                                                    <a href="<?= SystemURLs::getRootPath() ?>/people/family/<?= (int) $family['family_id'] ?>">
                                                        <?= InputUtils::escapeHTML($family['family_name']) ?>
                                                    </a>
                                                </td>
                                                <td class="align-middle">
                                                    <?php if (!empty($pledge['person_id']) && !empty($pledge['person_name'])): ?>
                                                        <a href="<?= SystemURLs::getRootPath() ?>/people/person/<?= (int) $pledge['person_id'] ?>">
                                                            <?= InputUtils::escapeHTML($pledge['person_name']) ?>
                                                        </a>
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary-lt text-secondary"><?= gettext('Entire Family') ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <?php if (SystemConfig::getBooleanValue('bUseDonationEnvelopes')): ?>
                                                <td class="align-middle text-body-secondary small">
                                                    <?= InputUtils::escapeHTML($family['envelope'] ?? '') ?>
                                                </td>
                                                <?php endif; ?>
                                                <td><?= InputUtils::escapeHTML($pledge['fund_name']) ?></td>
                                                <td class="text-end">
                                                    <?= CurrencyFormatter::formatHtml($pledge['pledge_amount']) ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require SystemURLs::getDocumentRoot() . '/Include/Footer.php'; ?>
