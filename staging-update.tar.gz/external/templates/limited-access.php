<?php

use ChurchCRM\dto\ChurchMetaData;
use ChurchCRM\dto\SystemURLs;
use ChurchCRM\Utils\InputUtils;

$sPageTitle = gettext('My Account');
// Plain auth background (no church-photo/dark overlay): this self-service landing
// has no solid login card, so the dark page-login background made its text
// unreadable. Matches the verify page it links to. See #8519.
$sBodyClass = 'page-auth';

require SystemURLs::getDocumentRoot() . '/Include/HeaderNotLoggedIn.php';
?>

<div class="login-container">
  <div class="login-wrapper">
    <div class="login-form-section">
      <div class="login-form-inner">
        <!-- Header with Logo -->
        <div class="login-form-header">
          <div class="login-header-logo">
            <img src="<?= SystemURLs::getRootPath() ?>/Images/churchcrm-logo-ink-blue.svg" alt="<?= InputUtils::escapeAttribute(ChurchMetaData::getChurchName() ?: 'ChurchCRM') ?>" />
          </div>
        </div>

        <!-- Greeting -->
        <div class="login-form-title">
          <?php if (!empty($userName)): ?>
          <h1><?= gettext('Welcome') ?>, <?= htmlspecialchars($userName) ?></h1>
          <?php else: ?>
          <h1><?= gettext('Welcome') ?></h1>
          <?php endif; ?>
          <?php if (!empty($verifyUrl)): ?>
          <p><?= gettext('You can review and verify your family information using the link below. If you need additional access, please contact your church administrator.') ?></p>
          <?php else: ?>
          <p><?= gettext('If you need additional access, please contact your church administrator.') ?></p>
          <?php endif; ?>
        </div>

        <!-- Action Buttons -->
        <div class="d-grid gap-2 mb-3">
          <?php if (!empty($verifyUrl)): ?>
          <a href="<?= htmlspecialchars($verifyUrl) ?>" class="btn btn-primary btn-lg">
            <i class="fa-solid fa-clipboard-check me-2"></i><?= gettext('Verify Family Info') ?>
          </a>
          <?php endif; ?>
          <a href="<?= SystemURLs::getRootPath() ?>/session/end" class="btn btn-outline-secondary">
            <i class="fa-solid fa-right-from-bracket me-2"></i><?= gettext('Log Out') ?>
          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
require SystemURLs::getDocumentRoot() . '/Include/FooterNotLoggedIn.php';
